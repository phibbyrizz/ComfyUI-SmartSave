import os
import re
import json
import time
import shutil
import urllib.request
from PIL import Image

DRY_RUN = False

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ALIAS_FILE = os.path.join(SCRIPT_DIR, "aliases.json")

POTENTIAL_OUTPUT_DIRS = [
    os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", "output")),
    os.path.abspath(os.path.join(SCRIPT_DIR, "output")),
    r"C:\Users\grant\Downloads\ComfyUI-Easy-Install\ComfyUI-Easy-Install\ComfyUI\output"
]

OUTPUT_DIR = next((d for d in POTENTIAL_OUTPUT_DIRS if os.path.exists(d)), POTENTIAL_OUTPUT_DIRS[0])
OLLAMA_MODEL = "llama3.2:3b"

# Load local aliases if present
NAME_ALIASES = {}
if os.path.exists(ALIAS_FILE):
    try:
        with open(ALIAS_FILE, "r", encoding="utf-8") as f:
            NAME_ALIASES = json.load(f)
    except Exception:
        pass

BLACKLIST_WORDS = {
    "raw", "comfyui", "image", "unsorted", "temp", "cartoon", "doll", 
    "general", "kneeup", "detailed", "hq", "moody", "upscaled", "scale", 
    "portrait", "closeup", "cinematic", "photo", "4k", "8k", "dai"
}

REFUSAL_TRIGGERS = [
    "i cannot", "i can't", "cannot fulfill", "can't fulfill", 
    "explicit content", "illegal substances", "as an ai", "policy", 
    "i am unable", "my safety"
]

def sanitize(name):
    clean = re.sub(r'[\\/*?:"<>|]', "", str(name)).strip()
    clean = clean.replace(" ", "_")
    clean = re.sub(r'_+', '_', clean)
    clean = clean.strip("_")
    low = clean.lower()
    if low in NAME_ALIASES:
        return NAME_ALIASES[low]
    return clean if clean else "Unsorted"

def is_refusal_or_junk(text):
    if not text or len(text) > 35:
        return True
    low = text.lower()
    return any(trig in low for trig in REFUSAL_TRIGGERS)

def is_bad_folder(folder_name):
    low = folder_name.lower().strip()
    if low.startswith("dai_"):
        return True
    if low in ["doll", "cartoon", "general", "temp", "raw", "compressed", "unsorted"]:
        return True
    return False

def extract_clean_name(text):
    if not text:
        return None
    stem = os.path.splitext(text)[0]
    stem = re.sub(r'[_\s]?\d+$', '', stem)
    parts = re.split(r'[_\\/\s\-]+', stem)
    valid_parts = [p for p in parts if p.lower() not in BLACKLIST_WORDS and p]
    if valid_parts:
        candidate = sanitize("_".join(valid_parts))
        if candidate.lower() not in BLACKLIST_WORDS and not candidate.startswith("ComfyUI_temp"):
            return candidate
    return None

def get_subject_from_ollama(prompt_text, model=OLLAMA_MODEL):
    if not prompt_text or not prompt_text.strip():
        return "Unsorted"

    url = "http://127.0.0.1:11434/api/generate"
    instruction = (
        "Task: Perform named entity recognition on this text metadata. "
        "Identify and extract ONLY the name of the real or fictional person/character mentioned. "
        "Return just the name, nothing else. If none is found, return 'Unsorted'."
    )

    payload = {
        "model": model,
        "prompt": f"{instruction}\n\nInput Metadata: \"{prompt_text}\"\nExtracted Name:",
        "stream": False,
        "options": {"temperature": 0.0}
    }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as response:
            result = json.loads(response.read().decode("utf-8"))
            subject = result.get("response", "").strip()
            subject = subject.split("\n")[0].strip(" .\"'")
            if is_refusal_or_junk(subject):
                return "Unsorted"
            return sanitize(subject) if subject else "Unsorted"
    except Exception:
        return "Unsorted"

def extract_positive_prompt(file_path):
    if not file_path.lower().endswith(".png"):
        return ""
    try:
        with Image.open(file_path) as img:
            info = img.info
            if "user_positive_prompt" in info:
                return info["user_positive_prompt"]

            if "prompt" in info:
                graph = json.loads(info["prompt"])
                for nid, ndata in graph.items():
                    if "KSampler" in ndata.get("class_type", ""):
                        pos_ref = ndata.get("inputs", {}).get("positive")
                        if isinstance(pos_ref, list) and len(pos_ref) > 0:
                            pos_node_id = str(pos_ref[0])

                            def resolve(node_id, depth=0):
                                if depth > 6 or node_id not in graph:
                                    return ""
                                node = graph[node_id]
                                inputs = node.get("inputs", {})
                                if "text" in inputs:
                                    val = inputs["text"]
                                    if isinstance(val, str):
                                        return val
                                    elif isinstance(val, list) and len(val) > 0:
                                        return resolve(str(val[0]), depth + 1)
                                if "string_a" in inputs or "string_b" in inputs:
                                    a = resolve(str(inputs["string_a"][0])) if isinstance(inputs.get("string_a"), list) else inputs.get("string_a", "")
                                    b = resolve(str(inputs["string_b"][0])) if isinstance(inputs.get("string_b"), list) else inputs.get("string_b", "")
                                    delim = inputs.get("delimiter", ", ")
                                    return f"{a}{delim}{b}".strip()
                                return ""

                            text = resolve(pos_node_id)
                            if text:
                                return text
    except Exception:
        pass
    return ""

def get_next_counter(folder_path, prefix, ext):
    if not os.path.exists(folder_path):
        return 1
    existing = [f for f in os.listdir(folder_path) if f.startswith(prefix) and f.endswith(ext)]
    max_idx = 0
    pattern = re.compile(rf"^{re.escape(prefix)}_(\d+)\.{re.escape(ext)}$", re.IGNORECASE)
    for fname in existing:
        match = pattern.match(fname)
        if match:
            max_idx = max(max_idx, int(match.group(1)))
    return max_idx + 1

def run_resort():
    print(f"[*] Scanning output directory: {OUTPUT_DIR}")
    print(f"[*] Mode: {'[PREVIEW]' if DRY_RUN else '[LIVE EXECUTION]'}\n")

    if not os.path.exists(OUTPUT_DIR):
        print(f"[!] Directory not found: {OUTPUT_DIR}")
        return

    # PHASE 1: Collapse space-separated and alias folders directly
    for branch in ["Raw", "Compressed"]:
        branch_dir = os.path.join(OUTPUT_DIR, branch)
        if not os.path.exists(branch_dir):
            continue

        for folder in list(os.listdir(branch_dir)):
            folder_path = os.path.join(branch_dir, folder)
            if not os.path.isdir(folder_path):
                continue

            target_folder = sanitize(folder)
            if target_folder != folder and not is_bad_folder(folder):
                dest_path = os.path.join(branch_dir, target_folder)
                os.makedirs(dest_path, exist_ok=True)
                print(f"[+] Normalizing Directory: {branch}/{folder} -> {branch}/{target_folder}")
                for fname in os.listdir(folder_path):
                    src_file = os.path.join(folder_path, fname)
                    dst_file = os.path.join(dest_path, fname)
                    if not os.path.exists(dst_file):
                        shutil.move(src_file, dst_file)
                try:
                    if not os.listdir(folder_path):
                        os.rmdir(folder_path)
                except OSError:
                    pass

    # PHASE 2: Re-sort files, standardize naming, and extract prompts
    processed = 0
    for root, dirs, files in os.walk(OUTPUT_DIR):
        for f in files:
            if not f.lower().endswith(".png"):
                continue

            png_path = os.path.join(root, f)
            filename = f
            current_dir = root
            parent_folder = os.path.basename(current_dir)

            bad_parent = is_bad_folder(parent_folder)
            character = None

            if not bad_parent:
                character = extract_clean_name(parent_folder)

            if not character or bad_parent:
                prompt = extract_positive_prompt(png_path)
                if prompt:
                    character = get_subject_from_ollama(prompt)

            if not character or character == "Unsorted":
                character = extract_clean_name(filename)

            if not character or is_refusal_or_junk(character) or character.isdigit() or re.match(r'^\d+$', character):
                character = "Unsorted"

            character = sanitize(character)

            raw_target_dir = os.path.join(OUTPUT_DIR, "Raw", character)
            comp_target_dir = os.path.join(OUTPUT_DIR, "Compressed", character)

            if os.path.normpath(current_dir) == os.path.normpath(raw_target_dir) and filename.startswith(f"{character}_"):
                continue

            counter = get_next_counter(raw_target_dir, character, "png")
            new_png_name = f"{character}_{counter:05d}.png"
            new_png_path = os.path.join(raw_target_dir, new_png_name)

            print(f"[+] Moving Raw: {os.path.join(parent_folder, filename)} -> Raw/{character}/{new_png_name}")
            if not DRY_RUN:
                os.makedirs(raw_target_dir, exist_ok=True)
                os.makedirs(comp_target_dir, exist_ok=True)
                shutil.move(png_path, new_png_path)

            stem = os.path.splitext(filename)[0]
            jpg_candidates = [
                os.path.join(current_dir, f"{stem}.jpg"),
                os.path.join(current_dir, f"{stem}.jpeg"),
                os.path.join(OUTPUT_DIR, "Compressed", parent_folder, f"{stem}.jpg"),
                png_path.replace("Raw", "Compressed").replace(".png", ".jpg")
            ]

            for cand in jpg_candidates:
                if os.path.exists(cand):
                    new_jpg_name = f"{character}_{counter:05d}.jpg"
                    new_jpg_path = os.path.join(comp_target_dir, new_jpg_name)
                    print(f"    Moving JPG: {os.path.basename(cand)} -> Compressed/{character}/{new_jpg_name}")
                    if not DRY_RUN:
                        shutil.move(cand, new_jpg_path)
                    break

            processed += 1

    # PHASE 3: Standardize filenames inside character folders
    if not DRY_RUN:
        for branch in ["Raw", "Compressed"]:
            branch_dir = os.path.join(OUTPUT_DIR, branch)
            if not os.path.exists(branch_dir):
                continue

            for char_folder in os.listdir(branch_dir):
                char_path = os.path.join(branch_dir, char_folder)
                if not os.path.isdir(char_path):
                    continue

                for f in sorted(os.listdir(char_path)):
                    file_path = os.path.join(char_path, f)
                    if not os.path.isfile(file_path):
                        continue

                    stem, ext = os.path.splitext(f)
                    ext_clean = ext.lstrip(".").lower()

                    if not f.startswith(f"{char_folder}_"):
                        counter = get_next_counter(char_path, char_folder, ext_clean)
                        new_f = f"{char_folder}_{counter:05d}{ext}"
                        print(f"[!] Standardizing: {branch}/{char_folder}/{f} -> {new_f}")
                        shutil.move(file_path, os.path.join(char_path, new_f))

        # PHASE 4: Robust Empty Folder Purge
        print("\n[*] Purging residual empty directories...")
        time.sleep(0.5)
        deleted_count = 0
        protected_folders = {
            os.path.normpath(OUTPUT_DIR).lower(),
            os.path.normpath(os.path.join(OUTPUT_DIR, "Raw")).lower(),
            os.path.normpath(os.path.join(OUTPUT_DIR, "Compressed")).lower()
        }

        for root, dirs, _ in os.walk(OUTPUT_DIR, topdown=False):
            for dir_name in dirs:
                dir_path = os.path.join(root, dir_name)
                norm_dir = os.path.normpath(dir_path).lower()

                if norm_dir in protected_folders:
                    continue

                try:
                    if os.path.exists(dir_path) and not os.listdir(dir_path):
                        os.rmdir(dir_path)
                        rel_path = os.path.relpath(dir_path, OUTPUT_DIR)
                        print(f"    Deleted empty folder: {rel_path}")
                        deleted_count += 1
                except OSError:
                    pass

        print(f"\n[✓] Done. Cleaned {processed} files and purged {deleted_count} empty directories.")

if __name__ == "__main__":
    run_resort()