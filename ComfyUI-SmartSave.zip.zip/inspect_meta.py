import json
from PIL import Image

# Put the exact path to one of the Billie Eilish images in Unsorted here:
IMAGE_PATH = r"C:\Users\grant\Downloads\ComfyUI-Easy-Install\ComfyUI-Easy-Install\ComfyUI\output\Raw\Miscellaneous\Miscellaneous_00003.png"

with Image.open(IMAGE_PATH) as img:
    info = img.info
    print(f"[*] Keys found in metadata: {list(info.keys())}")
    
    if "user_positive_prompt" in info:
        print(f"\n[+] Direct user_positive_prompt found:\n{info['user_positive_prompt']}")
    elif "prompt" in info:
        print("\n[*] 'prompt' graph exists. Scanning nodes...")
        graph = json.loads(info["prompt"])
        for nid, ndata in graph.items():
            inputs = ndata.get("inputs", {})
            class_type = ndata.get("class_type", "")
            # Print any text-bearing nodes
            if "text" in inputs:
                print(f"  -> Node {nid} ({class_type}) text: {inputs['text']}")
    else:
        print("\n[-] No prompt metadata found.")