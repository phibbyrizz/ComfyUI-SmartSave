import os
import subprocess

TARGET_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "output"))
PROTECTED = {"raw", "compressed"}

def purge_empty_folders(base_path):
    print(f"Purging empty folders in: {base_path}\n")

    # 1. Strip hidden/system locks (Thumbs.db, desktop.ini)
    for root, _, files in os.walk(base_path):
        for f in files:
            if f.lower() in ["thumbs.db", "desktop.ini"]:
                file_path = os.path.join(root, f)
                try:
                    subprocess.run(f'attrib -h -r -s "{file_path}"', shell=True)
                    os.remove(file_path)
                except Exception:
                    pass

    # 2. Delete folders that contain zero files
    deleted_count = 0
    for root, dirs, _ in os.walk(base_path, topdown=False):
        for d in dirs:
            dir_path = os.path.join(root, d)
            norm_name = d.lower()

            # Never delete the main Raw or Compressed containers
            if norm_name in PROTECTED and os.path.dirname(dir_path) == base_path:
                continue

            # Check if directory is empty of actual files and subfolders
            try:
                contents = os.listdir(dir_path)
                if not contents:
                    subprocess.run(f'cmd /c "rmdir /s /q "{dir_path}""', shell=True)
                    print(f"Deleted empty folder: {os.path.relpath(dir_path, base_path)}")
                    deleted_count += 1
            except Exception as e:
                print(f"Could not delete {d}: {e}")

    print(f"\nPurge complete! Removed {deleted_count} empty directories.")

if __name__ == "__main__":
    purge_empty_folders(TARGET_DIR)